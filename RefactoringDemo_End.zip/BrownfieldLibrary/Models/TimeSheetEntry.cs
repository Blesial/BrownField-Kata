﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrownfieldLibrary.Models
{
    public class TimeSheetEntryModel
    {
        public string WorkDone { get; set; }
        public double HoursWorked { get; set; }
    }
}
